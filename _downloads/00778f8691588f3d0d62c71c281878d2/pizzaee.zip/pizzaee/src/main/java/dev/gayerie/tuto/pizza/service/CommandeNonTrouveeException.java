package dev.gayerie.tuto.pizza.service;

public class CommandeNonTrouveeException extends Exception {

	private static final long serialVersionUID = -601263677147057297L;

}
