package dev.gayerie.tuto.pizza.model;

public enum BasePizza {
	
	TOMATE, CREME

}
