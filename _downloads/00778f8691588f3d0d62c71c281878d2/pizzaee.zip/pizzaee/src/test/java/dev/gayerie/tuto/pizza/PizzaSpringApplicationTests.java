package dev.gayerie.tuto.pizza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzaSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
