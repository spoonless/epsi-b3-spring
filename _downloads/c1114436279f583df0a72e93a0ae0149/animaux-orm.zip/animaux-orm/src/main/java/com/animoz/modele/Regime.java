package com.animoz.modele;

public enum Regime {
	carnivore, herbivore
}
