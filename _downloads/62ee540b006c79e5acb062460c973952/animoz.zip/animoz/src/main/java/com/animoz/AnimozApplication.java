package com.animoz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnimozApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnimozApplication.class, args);
	}

}
